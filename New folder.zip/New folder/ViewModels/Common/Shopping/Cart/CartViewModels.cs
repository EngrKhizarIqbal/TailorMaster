﻿using Cazon.ViewModel.Infrastructure.Attribute.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Cazon.ViewModel.Common.Shopping.Cart
{
    public abstract class CartProductBaseDTO
    {
        [Required]
        [NonZero]
        public int ProductId { get; set; }
    }

    public class AddProductToCartDTO : CartProductBaseDTO
    {
    }

    public class RemoveProductFromCartDTO : CartProductBaseDTO
    {

    }

    public class UpdateCartProductDTO : CartProductBaseDTO
    {
        [Required]
        [NonZero]
        public int Quanttiy { get; set; }
    }

    public class ViewCartDTO
    {
        public ViewCartDTO()
        {
            CartItems = new List<ViewCartItemDTO>();
        }

        public int CartId { get; set; }

        public List<ViewCartItemDTO> CartItems { get; set; }

        public double CartTotal
        {
            get
            {
                var cartTotal = 0.0;

                foreach (var item in CartItems)
                    cartTotal += (item.ProductPrice * item.Quantity);

                return cartTotal;
            }
        }
    }

    public class ViewCartItemDTO
    {
        public int CartItemId { get; set; }

        public int Quantity { get; set; }

        public DateTime AddedOn { get; set; }

        public int ProductId { get; set; }
        public string ProductName { get; set; }

        public double ProductPrice { get; set; }

        public string Description { get; set; }

        public string ProductImageName { get; set; }

        public int QuantityInStock { get; set; }

        public int ProductCategoryId { get; set; }

        public string ProductCategoryName { get; set; }

        public int CazonShopId { get; set; }

        public string CazonShopName { get; set; }
    }
}
