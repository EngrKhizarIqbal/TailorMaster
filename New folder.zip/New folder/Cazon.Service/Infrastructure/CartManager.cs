﻿using System.Web;

namespace Cazon.Service.Infrastructure
{
    public static class CartManager
    {
        public static string SessionCartIdKey { get; } = "CurrentCartId";

        public static int CurrentCartId
        {
            get
            {
                var cartId = HttpContext.Current.Session[SessionCartIdKey];
                return cartId != null ? int.Parse(cartId.ToString()) : -1;
            }
        }
    }
}
