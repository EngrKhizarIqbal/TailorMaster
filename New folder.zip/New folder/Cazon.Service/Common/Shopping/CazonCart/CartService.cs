﻿using System.Threading.Tasks;
using Cazon.Service.Common.Contract.Shopping;
using Cazon.Service.Infrastructure;
using Cazon.Models.Shopping.CazonCart;
using Cazon.Repository.Shopping.CazonCart;
using Cazon.Repository;
using System.Web;
using Cazon.ViewModel.Common.Shopping.Cart;
using System.Linq;

namespace Cazon.Service.Common.Shopping.CazonCart
{
    public abstract class CartService : CazonBaseService, ICartService
    {
        protected CartRepo Repo;
        protected CazonProductRepo ProductRepo;
        protected CartItemRepo CartItemRepo;

        public CartService()
        {
            Repo = new CartRepo();
            ProductRepo = new CazonProductRepo();
            CartItemRepo = new CartItemRepo();

            DisposableObjects.Add(Repo);
            DisposableObjects.Add(ProductRepo);
            DisposableObjects.Add(CartItemRepo);
        }

        public override Task<bool> IsEntityExists(object id)
        {
            return Repo.IsEntityExists(f => f.CartId == (int)id);
        }

        public async Task<CazonResult<ViewCartDTO>> GetCurrentCartDetails()
        {
            var result = new CazonResult<ViewCartDTO>();

            var cart = await Repo.FindById(new object[] { CartManager.CurrentCartId }, c => c.CartItems);

            if(cart != null)
            {
                result.Result = new ViewCartDTO
                {
                    CartId = cart.CartId,
                    CartItems = cart.CartItems.Select(c => new ViewCartItemDTO
                    {
                        CartItemId = c.CartItemId,
                        ProductId = c.ProductId,
                        AddedOn = c.AddedOn,
                        ProductName = c.Product.Name,
                        ProductPrice = c.Product.Price,
                        Quantity = c.Quantity,
                        Description = c.Product.Description,
                        QuantityInStock = c.Product.QuantityInStock,
                        ProductImageName = c.Product.Images.FirstOrDefault(i => i.IsDefault == true).ImgName,
                        CazonShopId = c.Product.CazonShopId,
                        CazonShopName = c.Product.CazonShop.Name,
                        ProductCategoryId = c.Product.ProductCategoryId,
                        ProductCategoryName = c.Product.ProductCategory.CategoryName
                    })
                    .ToList()
                };

                result.Success = true;
            }
            else
            {
            }

            return result;
        }

        public async Task<CazonResult<bool>> AddProductToCart(AddProductToCartDTO model)
        {
            var result = new CazonResult<bool>();
            if (!await ProductRepo.IsEntityExists(model.ProductId))
            {
                result.Errors.Add("This product is not exists at our site.");
                result.Result = false;
            }
            else
            {
                var currentCart = await GetCurrentCart();
                if (!await CartItemRepo.IsProductInTheCart(CartManager.CurrentCartId, model.ProductId))
                {
                    currentCart.CartItems.Add(new CartItem
                    {
                        ProductId = model.ProductId,
                        Quantity = 1
                    });

                    await Repo.UpdateEntity(currentCart);
                    result.Success = true;
                    result.Result = true;
                }
                else
                {
                    result.Errors.Add("This product is already in the cart.");
                    result.Result = false;
                }
            }
            return result;
        }

        public async Task<CazonResult<bool>> UpdateCartItem(UpdateCartProductDTO model)
        {
            var result = new CazonResult<bool>();
            if (!await ProductRepo.IsEntityExists(model.ProductId))
            {
                result.Errors.Add("This product is not exists at our site.");
                result.Result = false;
            }
            else if(!IsCartExpired(result))
            {
                var cartItem = await CartItemRepo.GetCartItemByCartAndProductId(CartManager.CurrentCartId, model.ProductId);
                if (cartItem != null)
                {
                    cartItem.Quantity = model.Quanttiy;
                    await CartItemRepo.UpdateEntity(cartItem);
                    result.Success = true;
                    result.Result = true;
                }
                else
                {
                    result.Errors.Add("This product is not in the cart.");
                    result.Result = false;
                }
            }

            return result;
        }

        public async Task<CazonResult<bool>> RemoveProductFromCart(RemoveProductFromCartDTO model)
        {
            var result = new CazonResult<bool>();
            if (!await ProductRepo.IsEntityExists(model.ProductId))
            {
                result.Errors.Add("This product is not exists at our site.");
                result.Result = false;
            }
            else if(!IsCartExpired(result))
            {
                var cartItem = await CartItemRepo.GetCartItemByCartAndProductId(CartManager.CurrentCartId, model.ProductId);
                if (cartItem != null)
                {
                    await CartItemRepo.DeleteEntity(cartItem);
                    result.Success = true;
                    result.Result = true;
                }
                else
                {
                    result.Errors.Add("This product is not in the cart.");
                    result.Result = false;
                }
            }

            return result;
        }

        protected async Task<Cart> GetCurrentCart()
        {
            var currentCart = await (CazonIdentityManager.IsLoggedIn ? Repo.GetCartByUserId(CazonIdentityManager.CurrentUserId) : Repo.GetCartBySessionId(CazonIdentityManager.CurrentSessionId));

            if(currentCart == null)
            {
                currentCart = new Cart
                {
                     SessionId = CazonIdentityManager.CurrentSessionId
                };

                if (CazonIdentityManager.IsLoggedIn)
                    currentCart.UserId = CazonIdentityManager.CurrentUserId;

                await Repo.AddEntity(currentCart);
            }

            HttpContext.Current.Session[CartManager.SessionCartIdKey] = currentCart.CartId;

            return currentCart;
        }

        protected async Task<int> GetCurrentCartId()
        {
            var cartId = CartManager.CurrentCartId;

            if(cartId == -1)
            {
                var currentCart = await GetCurrentCart();
                cartId = currentCart.CartId;
            }

            return cartId;
        }

        protected bool IsCartExpired<TResult>(CazonResult<TResult> result)
        {
            var cartId = CartManager.CurrentCartId;
            if (cartId == -1)
                result.Errors.Add("Sorry, your cart is expired.");

            return (cartId == -1);
        }
    }
}
